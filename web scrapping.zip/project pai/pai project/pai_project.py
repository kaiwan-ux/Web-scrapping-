import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import csv

chromeoptions = webdriver.ChromeOptions()
# chromeoptions.add_argument("--headless") #Uncomment this line to run in headless mode
driver = webdriver.Chrome(options=chromeoptions)
x = 0

data = {
    "restaurant": [],
    "dates": [],
    "rating": [],
    "reviews": [], 
}

# Open the URL
driver.get("https://www.opentable.com/r/arno-ristorante-new-york-2?corrid=4d4af7aa-ec40-4bc6-9f33-c5fd7dee30bc&avt=eyJ2IjoyLCJtIjoxLCJwIjowLCJzIjowLCJuIjowfQ&p=2&sd=2024-11-30T19%3A00%3A00&page=1")
driver.execute_script("window.scrollBy(0, 5650);")  # Scrolls according to your site until you reach the footer or next button
while True:
    
    reviews = driver.find_elements(By.CSS_SELECTOR, "._6rFG6U7PA6M-")
    times = driver.find_elements(By.CSS_SELECTOR, "p.iLkEeQbexGs-")
    rating = driver.find_elements(By.CSS_SELECTOR, "div.yEKDnyk-7-g-")
    
    for review, tim, rate in zip(reviews, times, rating):
        review_text = review.text.strip()
        tim = tim.text[9:]
        rate = rate.get_attribute("aria-label")[0]

        if review_text and x <= 1500:
            x += 1
            data["reviews"].append(review_text)
            data["dates"].append(tim)
            data["rating"].append(rate)  
            data["restaurant"].append("Arno Ristorante")
            
        else:
            break

    try:
        next_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[data-test="pagination-next"]'))
        )
        next_button.click()
        time.sleep(3)
    except TimeoutException:
        break  # If no next button is found or clickable, break the loop

driver.quit()

# Save the scraped data into a CSV file
with open('arno_ristorante_reviews.csv', 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['restaurant', 'dates', 'rating', 'reviews']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    for i in range(len(data['restaurant'])):
        writer.writerow({
            'restaurant': data['restaurant'][i],
            'dates': data['dates'][i],
            'rating': data['rating'][i],
            'reviews': data['reviews'][i]
        })
